import React from 'react';
import { useState ,useRef } from 'react';
import Todolist from './Todolist';
import { v4 as uuidv4 } from 'uuid';//used this for getting random id

function App(){

	const [todos ,setask] = useState ([]) //creates empty list for storing tasks
    const taskname = useRef()  // whatever we input in input area , this varaible is refered to that input

	function toogletodo(id){ // for switching the task as checked unchecked
		const newtasklist = [...todos]  
		const todo = newtasklist.find (todo => todo.id === id)
		todo.complete = !todo.complete // makes the invert
		setask(newtasklist)
	}
    
	function addtask(e){
		const name = taskname.current.value
		if (name === '') return
		setask(
			prevtask => {
				return [...prevtask , { id: uuidv4() ,name: name , complete:false }]  //sets id to the task and add to the list
			}
		)
		taskname.current.value = null //keeps default value as nothing is showned
	}

	function removetask(){
		const newtask = todos.filter(todo => !todo.complete) // gets tasks that are not completdd yet into this variable 
		setask(newtask)  // updates the tasks , this will remove checked item by ignoring them
	}


	return(
        <>
		<div>
			<h1>To Do List</h1>
		</div>

		<Todolist todos ={todos} toogletodo={toogletodo}/>
		{/* our tasks are displayed through this  */}
        <input ref={taskname} type='text'/>

		<button onClick={addtask}>Add todo</button>
		<button onClick={removetask}>Clear</button>
        
		<div>{todos.filter(todo => !todo.complete).length} tasks left to do</div>
		</>

	)
}
export default App