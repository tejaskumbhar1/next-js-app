import React from 'react'

function Todo(todo ,toogletodo) {
  
  function todoclick(){       // for check and uncheck functionality
      toogletodo(todo.id)
  }
  
  //it is the structure of task we that will be displayed 
  // a check box and name

  return (
    <div>
        <label>
             <input type ='checkbox' checked={todo.complete} onChange={todoclick}/>
             {todo.name}

        </label>
    </div>
  )
}

export default Todo
