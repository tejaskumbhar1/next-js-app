import React from 'react'
import Todo from './Todo'

//represents the  list of tassks
// iterates through each task
// todo then returns the structure 
function Todolist({todos , toogletodo}) {
  return (
   
      todos.map(
        todo => {
          return <Todo key={todo.id} toogletodo={toogletodo} todo={todo}/>
        }
      )
  )  
    
}

export default Todolist
